const questions = [
  {
    id: "name",
    question: "👋 First, what's your full name?",
  },

  {
    id: "phone",
    question: "📱 Great! What's your phone number?",
  },

  {
    id: "email",
    question: "📧 What's your email address?",
  },

  {
    id: "resident",
    question: "🏠 Are you a UAE Resident?",
    options: [
      "UAE Resident",
      "Non-Resident",
    ],
  },

  {
    id: "purpose",
    question: "🎯 What are you looking for?",
    options: [
      "Home Purchase",
      "Refinance",
      "Mortgage Transfer",
      "Investment Property",
    ],
  },

  {
    id: "property",
    question: "🏡 What's the estimated property value (AED)?",
  },

  {
    id: "income",
    question: "💰 What's your monthly income (AED)?",
  },
];

export default questions;