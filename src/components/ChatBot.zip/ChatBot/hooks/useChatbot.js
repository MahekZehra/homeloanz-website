import { useState } from "react";
import questions from "../data/questions";

export default function useChatbot() {
  const [step, setStep] = useState(0);

  const [answers, setAnswers] = useState({});

  const currentQuestion = questions[step];

  const submitAnswer = (answer) => {
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: answer,
    }));

    setStep(step + 1);
  };

  return {
    currentQuestion,
    submitAnswer,
    answers,
    finished: step >= questions.length,
  };
}