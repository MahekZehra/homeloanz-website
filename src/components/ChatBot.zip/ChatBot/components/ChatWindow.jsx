import { X } from "lucide-react";
import WelcomeScreen from "./WelcomeScreen";

const ChatWindow = ({ closeChat }) => {
  return (
    <div className="flex h-full flex-col">

      {/* Header */}
      <div className="flex items-center justify-between bg-[#0B3C5D] px-5 py-4 text-white">

        <div>
          <h2 className="text-xl font-bold">
            🏠 HomeLoanz Assistant
          </h2>

          <div className="mt-1 flex items-center gap-2 text-sm text-white/80">
            <div className="h-2 w-2 rounded-full bg-green-400"></div>
            Online
          </div>
        </div>

        <button
          onClick={closeChat}
          className="rounded-lg p-2 transition hover:bg-white/10"
        >
          <X size={22} />
        </button>

      </div>

      {/* Body */}
      <div className="flex-1 bg-white">
        <WelcomeScreen
  onStart={() => alert("Next step: Questions will start here!")}
/>
      </div>

    </div>
  );
};

export default ChatWindow;