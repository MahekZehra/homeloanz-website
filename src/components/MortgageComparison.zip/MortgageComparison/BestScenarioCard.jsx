import { Trophy, CheckCircle2 } from "lucide-react";
import Card from "../ui/Card";
import { motion } from "framer-motion";
import CountUp from "react-countup";


const BestScenarioCard = ({
  rate,
  monthlyPayment,
  saving,
  loanAmount,
  totalInterest,
  totalPayment,
}) => {

  return (
   <motion.div
    initial={{ opacity: 0, y: 40 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6 }}
    viewport={{ once: true }}
    >
    <Card
     className="mt-10 p-8">

      <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">


        {/* Left Side */}

        <div>


          <div className="mb-4 flex items-center gap-3">


            <div className="
              flex
              h-12
              w-12
              items-center
              justify-center
              rounded-2xl
              bg-emerald-400/10
            ">

              <Trophy
                className="text-emerald-400"
                size={24}
              />

            </div>


            <span className="
              uppercase
              tracking-[3px]
              text-emerald-400
              font-semibold
            ">

              Best Mortgage Scenario

            </span>


          </div>



          <h3 className="
            text-3xl
            font-bold
            text-white
          ">

            Choose {rate}% Interest Rate

          </h3>


          <p className="
            mt-3
            max-w-xl
            text-slate-400
          ">

            Based on your selected loan details,
            this option gives you the lowest estimated
            mortgage cost.

          </p>


        </div>




        {/* Right Side Stats */}


        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">



          <div className="
            rounded-2xl
            bg-white/5
            p-5
          ">

            <p className="text-sm text-slate-400">
              Monthly Payment
            </p>


            <h4 className="
              mt-2
              text-2xl
              font-bold
              text-white
            ">

            AED{" "}
<CountUp
  end={monthlyPayment}
  duration={0.8}
  separator=","
/>

            </h4>


          </div>




          <div className="
            rounded-2xl
            bg-emerald-400/10
            p-5
          ">


            <div className="flex items-center gap-2">

              <CheckCircle2
                size={18}
                className="text-emerald-400"
              />

              <p className="text-sm text-emerald-400">
                Estimated Saving
              </p>
 
 <div className="rounded-2xl bg-white/5 p-5">
  <p className="text-sm text-slate-400">
    Loan Amount
  </p>

  <h4 className="mt-2 text-2xl font-bold text-white">
   AED{" "}
<CountUp
  end={loanAmount}
  duration={0.8}
  separator=","
/>
  </h4>
</div>

<div className="rounded-2xl bg-white/5 p-5">
  <p className="text-sm text-slate-400">
    Total Interest
  </p>

  <h4 className="mt-2 text-2xl font-bold text-white">
    AED{" "}
<CountUp
  end={totalInterest}
  duration={0.8}
  separator=","
/>
  </h4>
</div>

<div className="rounded-2xl bg-white/5 p-5">
  <p className="text-sm text-slate-400">
    Total Mortgage Cost
  </p>

  <h4 className="mt-2 text-2xl font-bold text-white">
    AED{" "}
<CountUp
  end={totalPayment}
  duration={0.8}
  separator=","
/>
  </h4>
</div>
            </div>


            <h4 className="
              mt-2
              text-2xl
              font-bold
              text-white
            ">

           
<CountUp
  end={saving}
  duration={0.8}
  separator=","
/>

            </h4>


          </div>



        </div>


      </div>

<div className="mt-10 flex justify-center">
  <button
    className="
      rounded-xl
      bg-cyan-500
      px-8
      py-4
      text-lg
      font-semibold
      text-white
      transition-all
      duration-300
      hover:bg-cyan-400
      hover:scale-105
    "
  >
    Book Free Consultation
  </button>
</div>
    </Card>
</motion.div>
  );

};


export default BestScenarioCard;